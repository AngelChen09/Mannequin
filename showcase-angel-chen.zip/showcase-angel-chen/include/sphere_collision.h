#ifndef SIGNED_INCIDENCE_MATRIX_SPARSE_H
#define SIGNED_INCIDENCE_MATRIX_SPARSE_H
#include <Eigen/Core>
#include <Eigen/Sparse>
// Adjust verticies to adhere to sphere collision
//
// Inputs: 
//   V          #V by 3 list of next vertex positions (at time t+∆t)
//   is_pinned  #loopup table to check if vertex pinned by comparing b
//   c          center of sphere to collide V with
//   radius     radius of sphere to collide V with
// Outputs:
//   V          #V by 3 list of next vertex positions (at time t+∆t) with collision adjustment
void sphere_collision(
  Eigen::MatrixXd &V,
  const std::vector<bool> &is_pinned,
  const Eigen::Vector3d &c,
  double radius);
#endif
