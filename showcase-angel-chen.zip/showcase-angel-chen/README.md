# CSC317 Showcase Fall 2025

### Title: Mannequin
### Personal Information: 
* Full Name: Angel Chen
* UTorID: chena126
* Student number: 1010461331
* Augmented Assignment: A8

### Instructions
#### 1. Build the program
```
> cd showcase-angel-chen
> mkdir build_release
> cd build_release
> cmake ../ -DCMAKE_BUILD_TYPE=Release
> make
```
#### 2. Run the program
```
// Still in the build_release directory
> ./masssprings_sparse ../data/showcase.json
```

#### Optionally, you can create the .json and .obj files yourself...
```
// Still in the build_release directory 

// Create a fully pinned model and waist-pinned skirt
// Note: this uses the skirt_scaled.obj file to allow the skirt to fit the model
> python3 ../src/json_generator.py

// Merge two .obj files together to display together
> python3 ../src/obj_merge.py
```

#### ...and you can also view the seperate models:
```
// Model
> ./masssprings_sparse ../data/model.json
// Skirt
> ./masssprings_sparse ../data/skirt.json
// Sphere
> ./masssprings_sparse ../data/sphere.json
```

### Description:
#### Objective:
The goal was to model the skirt from A8 onto a mannequin. I wanted to implement this so that if polished and heavily developed on, users can scan their body, generate a 3D model (currently using a mesh 3D model from Mixamo), and try on clothing to see how they would look and move with such clothing. 

#### New Feature:
The main feature I implemented was collision detection for the body and the skirt. The collision adjustment can be found in `sphere_collision.cpp` and it is added onto `fast_mass_springs_step_sparse` per each iteration at the end. 

#### Process:
Using the idea that we can simplify collision detection by using simple geometry shapes, I modelled a sphere with set radius and center to fit the mesh 3D model's waist. I had to use Blender to scale and transform the skirt's position so that it would fit on the model. Then, also in Blender, I took their sphere mesh and triangulated it, then exported it to use and test the skirt collision with first. After I was comfortable with how it looked on the sphere, I fitted it on the model and made minor adjustments.

I wrote two helper functions to create the main JSON file with the model and skirt details, including the vast amount of b values needed to pin the model. The second function was to merge the skirt and model .obj files. A8's read_json.h function was only able to process one object at a time, and considering assignment priorities, I decided to merge the two object files.

#### Future Improvements:
1. I want to rewrite the read_json.h file to process multiple objects and their respective png textures. This way, it would be easier to distinguish between the model and the skirt.

2. I also want to model the mannequin's waist with two spheres next time to simulate the hips and waist better. 


### Acknowledgements:
#### Sphere from Blender
Blender. (2025). UV Sphere Node - Blender 5.0 Manual. Blender.org. https://docs.blender.org/manual/en/latest/modeling/geometry_nodes/mesh/primitives/uv_sphere.htmlMixamo Inc. (n.d.). 
#### Model [X-Bot] from Mixamo
Mixamo. Www.mixamo.com. https://www.mixamo.com/#/
#### JSON creating library
Software Foundation. (2023). json — JSON encoder and decoder — Python 3.8.3rc1 documentation. Docs.python.org. https://docs.python.org/3/library/json.html