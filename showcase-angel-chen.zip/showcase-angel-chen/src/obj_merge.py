# Function to load and convert all data from obj files into lists
def obj_load(obj1):
    # Stores obj file data into list to return
    verticies = []
    textures = []
    normals = []
    faces = []
    objs = []

    with open(obj1, "r") as file:
        for line in file:
            if line.startswith("v "):
                verticies.append(line)
            elif line.startswith("vt "):
                textures.append(line)
            elif line.startswith("vn "):
                normals.append(line)
            elif line.startswith("f "):
                faces.append(line)
            elif line.startswith("o "):
                objs.append(line)

    return verticies, textures, normals, faces, objs


# Updates the face indexes to accomodate the additional obj v/vt/vn
def update_face_index(line, v_offset, t_offset, n_offset):
    sections = line.strip().split()[1:]
    updated_sections = []

    for s in sections:
        vals = s.split("/") # get the indexes

        v = int(vals[0]) + v_offset if vals[0] else 0
        vt = int(vals[1]) + t_offset if len(vals) > 1 and vals[1] else 0
        vn = int(vals[2]) + n_offset if len(vals) > 2 and vals[2] else 0

        updated_sections.append(f"{v}/{vt}/{vn}")

    # Triangulate the quad meshes
    triangles = []
    if (len(updated_sections) == 3):
        triangles.append("f " + " ".join(updated_sections) + "\n")
    elif (len(updated_sections) == 4):
        # split the quad into 2 triangles
        triangles.append(f"f {updated_sections[0]} {updated_sections[1]} {updated_sections[2]}\n")
        triangles.append(f"f {updated_sections[0]} {updated_sections[2]} {updated_sections[3]}\n")
    else:
        raise ValueError(f"Face with {len(updated_sections)} verticies not supported")
    
    return triangles
    

# Function to merge all object files into one object file with adjusted index positions
def obj_merge(obj1, obj2, obj_out):
    # Stores cumulative data for both obj files
    v1, t1, n1, f1, o1 = obj_load(obj1)
    v2, t2, n2, f2, o2 = obj_load(obj2)

    v_offset = len(v1)
    t_offset = len(t1)
    n_offset = len(n1)

    faces1 = []
    for line in f1:
        triangles = update_face_index(line, 0, 0, 0)
        faces1.extend(triangles)

    faces2 = []
    for line in f2:
        triangles = update_face_index(line, v_offset, t_offset, n_offset)
        faces2.extend(triangles)

    with open(obj_out, "w") as outfile:
        if o1:
            outfile.write(o1[0])
        for line in v1:
            outfile.write(line)
        for line in t1:
            outfile.write(line)
        for line in n1:
            outfile.write(line)
        for line in faces1:
            outfile.write(line + "\n")
        
        if o2:
            outfile.write(o2[0])
        for line in v2:
            outfile.write(line)
        for line in t2:
            outfile.write(line)
        for line in n2:
            outfile.write(line)
        for line in faces2:
            outfile.write(line + "\n")
    
    print(f"Merged files {obj1} and {obj2} into {obj_out}")

    

def main():
    obj_file1 = "../data/model.obj"
    # obj_file1 = "../data/sphere.obj"
    obj_file2 = "../data/skirt_scaled.obj"
    obj_outfile = "../data/showcase.obj"
    # obj_outfile = "../data/showcase_testing.obj"

    obj_merge(obj_file1, obj_file2, obj_outfile)


if __name__ == "__main__":
    main()