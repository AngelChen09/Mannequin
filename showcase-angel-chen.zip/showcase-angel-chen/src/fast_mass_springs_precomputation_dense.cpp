#include "fast_mass_springs_precomputation_dense.h"
#include "signed_incidence_matrix_dense.h"
#include <Eigen/Dense>

bool fast_mass_springs_precomputation_dense(
  const Eigen::MatrixXd & V,
  const Eigen::MatrixXi & E,
  const double k,
  const Eigen::VectorXd & m,
  const Eigen::VectorXi & b,
  const double delta_t,
  Eigen::VectorXd & r,
  Eigen::MatrixXd & M,
  Eigen::MatrixXd & A,
  Eigen::MatrixXd & C,
  Eigen::LLT<Eigen::MatrixXd> & prefactorization)
{
  /////////////////////////////////////////////////////////////////////////////
  // Replace with your code
  
  // 1. M, the diagonal matrix of masses
  M = Eigen::MatrixXd::Zero(V.rows(), V.rows());
  for (int i = 0; i < V.rows(); i++) {
    M(i, i) = m[i];
  }

  // 2. r, a vector of rest lengths
  // r_{ij} = \|p_i - p_j\|
  r = Eigen::VectorXd::Zero(E.rows());
  for (int i = 0; i < E.rows(); i++) {
    r[i] = (V.row(E(i, 0)) - V.row(E(i, 1))).norm();
  }

  // 3. A, the signed incidence matrix
  signed_incidence_matrix_dense(V.rows(), E, A);

  // 4. C, the selection matrix, p x n where C_{i, j} = 1 if the i-th pinned vertex has index j
  C = Eigen::MatrixXd::Zero(b.rows(), V.rows());
  for (int i = 0; i < b.rows(); i++) {
    for (int j = 0; j < V.rows(); j++) {
      if (b(i) == j) {
        C(i, j) = 1;
      }
    }
  }

  // 5. The matrix Q (Q1 + Q2)
  double w = 1e10;
  Eigen::MatrixXd Q = Eigen::MatrixXd::Identity(V.rows(),V.rows());
  Q = (k * A.transpose() * A) + (M / std::pow(delta_t, 2)) + (w * C.transpose() * C);
  /////////////////////////////////////////////////////////////////////////////
  prefactorization.compute(Q);
  return prefactorization.info() != Eigen::NumericalIssue;
}
