#include "fast_mass_springs_precomputation_sparse.h"
#include "signed_incidence_matrix_sparse.h"
#include <vector>

bool fast_mass_springs_precomputation_sparse(
  const Eigen::MatrixXd & V,
  const Eigen::MatrixXi & E,
  const double k,
  const Eigen::VectorXd & m,
  const Eigen::VectorXi & b,
  const double delta_t,
  Eigen::VectorXd & r,
  Eigen::SparseMatrix<double>  & M,
  Eigen::SparseMatrix<double>  & A,
  Eigen::SparseMatrix<double>  & C,
  Eigen::SimplicialLLT<Eigen::SparseMatrix<double> > & prefactorization)
{
  /////////////////////////////////////////////////////////////////////////////
  // Replace with your code
  const int n = V.rows();

  // 1. M, the diagonal matrix of masses
  std::vector<Eigen::Triplet<double> > Mijv;
  Mijv.reserve(n);
  for(int i = 0;i<n;i++) Mijv.emplace_back(i,i,m[i]);
  M.resize(V.rows(), V.rows());
  M.setFromTriplets(Mijv.begin(), Mijv.end());

  // 2. r, a vector of rest lengths
  // r_{ij} = \|p_i - p_j\|
  r.resize(E.rows());
  for (int i = 0; i < E.rows(); i++) {
    r[i] = (V.row(E(i, 0)) - V.row(E(i, 1))).norm();
  }

  // 3. A, the signed incidence matrix
  signed_incidence_matrix_sparse(V.rows(), E, A);

  // 4. C, the selection matrix, p x n where C_{i, j} = 1 if the i-th pinned vertex has index j
  const int b_rows = b.rows();
  std::vector<Eigen::Triplet<double> > Cijv;
  Cijv.reserve(b_rows);
  for (int i = 0; i < b_rows; i++) Cijv.emplace_back(i, b(i), 1.0);
  C.resize(b_rows, V.rows());
  C.setFromTriplets(Cijv.begin(), Cijv.end());

  // 5. The matrix Q (Q1 + Q2)
  double w = 1e10;
  // std::vector<Eigen::Triplet<double> > Qijv;
  Eigen::SparseMatrix<double> Q(n,n);
  Q = (k * A.transpose() * A) + (M / std::pow(delta_t, 2)) + (w * C.transpose() * C);
  // Q.setFromTriplets(Qijv.begin(),Qijv.end());
  /////////////////////////////////////////////////////////////////////////////
  prefactorization.compute(Q);
  return prefactorization.info() != Eigen::NumericalIssue;
}
