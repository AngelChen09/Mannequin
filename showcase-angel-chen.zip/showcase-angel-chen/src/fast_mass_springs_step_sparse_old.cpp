#include "fast_mass_springs_step_sparse.h"
#include <igl/matlab_format.h>

void fast_mass_springs_step_sparse(
  const Eigen::MatrixXd & V,
  const Eigen::MatrixXi & E,
  const double k,
  const Eigen::VectorXi & b,
  const double delta_t,
  const Eigen::MatrixXd & fext,
  const Eigen::VectorXd & r,
  const Eigen::SparseMatrix<double>  & M,
  const Eigen::SparseMatrix<double>  & A,
  const Eigen::SparseMatrix<double>  & C,
  const Eigen::SimplicialLLT<Eigen::SparseMatrix<double> > & prefactorization,
  const Eigen::MatrixXd & Uprev,
  const Eigen::MatrixXd & Ucur,
  Eigen::MatrixXd & Unext)
{
  //////////////////////////////////////////////////////////////////////////////
  // Replace with your code

  Unext = Ucur;
  Eigen::MatrixXd D(E.rows(), 3);
  Eigen::MatrixXd l = Ucur;
  double w = 1e10;

  for(int iter = 0;iter < 50;iter++)
  {
    // 1. Step 1: given current values of p, determine d_{ij} for each spring
    for (int i = 0; i < E.rows(); i++) {
      D.row(i) = r[i] * (Unext.row(E(i, 0)) - Unext.row(E(i, 1))).normalized();
    }

    // 2. Step 2: given all d_{ij} vectors, find positions p that minimize quadratic energy E 
    l = k * A.transpose() * D + (M * (2 * Ucur - Uprev) / std::pow(delta_t, 2)) + fext + w * C.transpose() * (C * V);
    Unext = prefactorization.solve(l);
  }
  //////////////////////////////////////////////////////////////////////////////
}
