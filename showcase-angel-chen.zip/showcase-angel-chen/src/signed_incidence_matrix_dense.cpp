#include "signed_incidence_matrix_dense.h"

void signed_incidence_matrix_dense(
  const int n,
  const Eigen::MatrixXi & E,
  Eigen::MatrixXd & A)
{
  //////////////////////////////////////////////////////////////////////////////
  // Replace with your code
  A = Eigen::MatrixXd::Zero(E.rows(),n);
  for (int e = 0; e < A.rows(); e++) {
    for (int k = 0; k < A.cols(); k++) {
      if (k == E(e, 0)) {
        // if k is the first vertex of e
        A(e, k) = 1;
      } else if (k == E(e, 1)) {
        // if k is the second vertex of e
        A(e, k) = -1;
      } else {
        A(e, k) = 0;
      }
    }
  }
  //////////////////////////////////////////////////////////////////////////////
}
