#include "sphere_collision.h"
#include <vector>

void sphere_collision(
  Eigen::MatrixXd &V,
  const std::vector<bool> &is_pinned,
  const Eigen::Vector3d &c,
  double radius)
{
    for (int i = 0; i < V.rows(); i++) {

        if (is_pinned[i]) {
            continue;
        }

        // if vertex is not pinned, can perform collision adjustment
        Eigen::Vector3d dist = V.row(i).transpose() - c;
        if ((dist.norm() < radius + 1e-12)) {
            V.row(i) = (c + dist.normalized() * radius).transpose();
        } 
    }
}